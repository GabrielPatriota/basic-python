import function

function.timer()
function.today()
function.calculator()